from django.contrib import admin
from EditTimeplan.models import AdminUser,Promotion

class UserAdmin(admin.ModelAdmin):
    list_display = ('nom', 'prenom', 'email', 'numero_telephone', 'mot_de_passe','promotion') # liste les champs que nous voulons sur l'affichage de la liste
admin.site.register(AdminUser, UserAdmin) # nous modifions cette ligne, en ajoutant un deuxième argument

class UserAdmin(admin.ModelAdmin):
    list_display = ('nom','annee','groupe') # liste les champs que nous voulons sur l'affichage de la liste
admin.site.register(Promotion, UserAdmin) # nous modifions cette ligne, en ajoutant un deuxième argument

# Register your models here.
