from django.shortcuts import render, redirect
from showtimeplan.forms import UserForm
from showtimeplan.models import User
from EditTimeplan.models import AdminUser
from django.urls import reverse
import random


""" 

def Save(request):
    id= request.session.get('id')
    if request.method == "POST":
        print("yes")
        vu_jour=request.POST['jour']
        vu_matiere= request.POST.get('matiere') #Les élements entre crochets sont les "name" des input dans le template. Les vu_ créées sont des variables qui récupèrent l'attribut "name du template.
        vu_hdebut= request.POST.get('hdebut')
        vu_hfin= request.POST.get('hfin')
        vu_salle= request.POST.get('salle')
        vu_teacher= request.POST.get('teacher')
        print(vu_jour)
        adminUser= AdminUser.objects.get(id=id)
        us = CoursProgrammer(jour=vu_jour, matiere=vu_matiere, heure_debut=vu_hdebut, heure_fin=vu_hfin,salle=vu_salle, teacher=vu_teacher,
                             promotion=adminUser.promotion)
                # Cette ligne sert à lier le champ dans la base de données(modèle) aux variables vu_
        us.save()
    return render(request,'EditTimeplan/AdminDashboard.html')


"""









def insertuser(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            if User.objects.filter(email=email).exists():
                form.add_error('email', 'Email déjà utilisé')
                
            form.save()
            prenom_user = form.cleaned_data['prenom']
            return redirect("bienvenue", prenom=prenom_user)
    else:
        form = UserForm()
        
    context = {'form': form}
    return render(request, 'showtimeplan/register.html', context)

#Page d'acceuil 
def index(request):
    return render(request, "showtimeplan/index.html")



def login(request):     #Vue d'identification. Elle vous identifie à partie de votre mot de passe et votre email et vous connecte à votre compte
    if request.method == 'POST':
        email = request.POST.get('email')
        mot_de_passe = request.POST.get('mot_de_passe')
        try:
            adminUser= AdminUser.objects.get(email=email,mot_de_passe=mot_de_passe)
            request.session['id'] = adminUser.id
            return redirect('dashboardAdmin')

        except AdminUser.DoesNotExist:
            try:
                user = User.objects.get(email=email, mot_de_passe=mot_de_passe) #Cette ligne permet de vérifier si l'utilisateur existe dans la base de données. Elle lance une recherche de l'email et du mot de passe qu'il a entré dans le champ de recherche dans la base de données
                
                return redirect('bienvenue_connexion', prenom=user.prenom)
            except User.DoesNotExist:

                context = {
                'error_message': 'Email ou mot de passe incorrect. Réessayez !',
                'email_value': email,  
                'password_value': mot_de_passe,
                }
                return render(request, 'showtimeplan/login.html', context)

    return render(request, 'showtimeplan/login.html')




def register(request):
    return render(request, "showtimeplan/register.html")

def bienvenue(request, prenom):
    return render(request, 'showtimeplan/bienvenue.html', {'prenom' : prenom})

def bienvenue_connexion(request, prenom):
    return render(request, 'showtimeplan/bienvenue_connexion.html', {'prenom' : prenom})






def dashboardStudent(request):
    return render(request,'showtimeplan/dashboardStudent.html')
    






#Voici mon idée ,c'est une alternative pour eviter de faire passer les information de l"utilisateur par l'url
"""
def cherche_le_compte(request):
    if request.method == 'POST':
        if 'email' in request.POST:
            email = request.POST['email']
            try:
                user = User.objects.get(email=email)
                return redirect('recuperation_de_compte', id=user.id)
            except User.DoesNotExist:
                return render(request, 'showtimeplan/timetable.html')
    return render(request, 'showtimeplan/bienvenue_connexion.html')



    def recuperation_compte(request, id):
    try:
        user = User.objects.get(id=id)
        context = {
            'prenom': user.prenom,
            'nom': user.nom
        }
        return render(request, 'showtimeplan/recuperation_de_compte.html', context)
    except User.DoesNotExist:
        return render(request, 'showtimeplan/error.html')
"""
        
"""
#Une autre alternative qui utilise les session
def cherche_le_compte(request):
    if request.method == 'POST':
        if 'email' in request.POST:
            email = request.POST['email']
            try:
                user = User.objects.get(email=email)
                request.session['prenom'] = user.prenom
                request.session['nom'] = user.nom
                return redirect('recuperation_de_compte', id=user.id)
            except User.DoesNotExist:
                return render(request, 'showtimeplan/timetable.html')
    return render(request, 'showtimeplan/bienvenue_connexion.html')


def recuperation_compte(request, id):
    prenom = request.session.get('prenom')
    nom = request.session.get('nom')

    context = {
        'prenom': prenom,
        'nom': nom
    }

    return render(request, 'showtimeplan/recuperation_de_compte.html', context)
  Avec cette approche, les informations ne seront pas visibles dans l'URL, mais elles seront stockées temporairement dans la session jusqu'à ce que l'utilisateur se déconnecte ou que la session expire.

N'oubliez pas de nettoyer les valeurs de session une fois qu'elles ne sont plus nécessaires, par exemple en utilisant del request.session['prenom'] et del request.session['nom'].
"""