from django.urls import path
from . import views

urlpatterns= [
    path("",views.index, name ="accueil"), 
    path("login/",views.login, name = "login"),
    path("insertuser/",views.insertuser, name="insertuser"),
    path('dashboard/',views.dashboardStudent,name="dashboardStudent"),
    path("register/",views.register, name="register"), #Page d'inscription
    path("bienvenue/<str:prenom>/",views.bienvenue, name ="bienvenue"),#Page temporaire
    path("bienvenue_connexion/<str:prenom>/",views.bienvenue_connexion, name="bienvenue_connexion"),#Page temporaire de connexion
]